<?php readfile("FLAG_4.txt"); ?>
